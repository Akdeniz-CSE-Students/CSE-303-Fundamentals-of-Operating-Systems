# CPU Emulator
### CPU emulator software that support a basic instruction set (15 instructions) given below
Assume that the computer has 256 bytes of available memory (M) initially set to zero.Emulator should load a program code from a text file. 
Assume that initially all flags are set to zero.

### Instruction Set
![Instruction Set](https://user-images.githubusercontent.com/86426656/215288958-d7964062-f256-4960-86e0-50dfa0a0ede0.jpg) 
#### Sample text file             
![Sample text file](https://user-images.githubusercontent.com/86426656/215288969-9d44645a-4f03-46ad-8ddd-0fff786f23f7.jpg)




